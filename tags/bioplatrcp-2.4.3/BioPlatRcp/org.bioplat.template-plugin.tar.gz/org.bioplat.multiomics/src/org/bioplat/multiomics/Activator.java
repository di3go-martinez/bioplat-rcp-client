package org.bioplat.multiomics;

import org.eclipse.ui.plugin.AbstractUIPlugin;

public class Activator extends AbstractUIPlugin {

	public Activator() {
		// TODO Auto-generated constructor stub
	}

}
